# 此Module只是为了让Android Studio能够索引当前项目的所有代码

# 为了解决搜代码搜不到的问题

# 禁止在里面添加任何逻辑!!!

# 禁止在里面添加任何逻辑!!!

# 禁止在里面添加任何逻辑!!!

# 禁止任何Module依赖此Module!!!

# 禁止任何Module依赖此Module!!!

# 禁止任何Module依赖此Module!!!